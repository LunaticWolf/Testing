package com.btrs.service.persistance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.btrs.model.entity.RouteTO;
import com.btrs.service.constants.QueryConstants;
import com.btrs.service.exception.MVCApplicationException;
import com.btrs.service.util.DBConnection;
import com.btrs.service.util.DBConnectionI;



public class RouteDAO implements RouteDAOI
{
	
	
	
	static Connection myConn=null;
	static PreparedStatement pStmt = null;	
	static ResultSet myRslt = null;
	static Statement stmt = null;
	
	
	
	

	
	
	
	
	//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< GENERATE ROUTE ID >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

	
	
		public String generateRouteId(String id) throws MVCApplicationException
		{
			
			String query = QueryConstants.GENERATE_ROUTE_ID;
			
			try
			{
				DBConnectionI db = new DBConnection();
				myConn = db.getMySQLConnection();
				
				stmt = myConn.createStatement();
				myRslt = stmt.executeQuery(query);
				
				if(myRslt.next())
				{
					id = myRslt.getString("route_id");
				}
				
			}
			catch(SQLException e)
			{
				throw new MVCApplicationException();
			}
			
			return id;
			
		}

		
		
		
		
		
		//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< ADD NEW ROUTE >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

		public boolean addNewRoute(RouteTO routeTO) throws MVCApplicationException 
		{
			
			boolean registered = false;
			
			DBConnection db = new DBConnection();
			
			try
			{
				myConn = db.getMySQLConnection();
				String query = QueryConstants.ADD_NEW_ROUTE;
				
				pStmt = myConn.prepareStatement(query);
				
				pStmt.setString(1, routeTO.getRouteId());
				pStmt.setString(2, routeTO.getRouteFrom());
				pStmt.setString(3, routeTO.getRouteTo());
				pStmt.setString(4, routeTO.getTravelCost());
				
				
				int n = pStmt.executeUpdate();
				
				if(n==1)
					registered = true;
			}
			catch(SQLException e)
			{
				throw new MVCApplicationException();
			}
			
			
			
				
				
			return registered;
		}
	
}
