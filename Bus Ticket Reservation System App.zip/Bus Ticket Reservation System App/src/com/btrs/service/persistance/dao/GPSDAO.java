package com.btrs.service.persistance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.btrs.model.entity.CityTO;
import com.btrs.model.entity.CountryTO;
import com.btrs.model.entity.StateTO;
import com.btrs.model.entity.ZipCodeTO;
import com.btrs.service.constants.QueryConstants;
import com.btrs.service.exception.MVCApplicationException;
import com.btrs.service.util.DBConnection;
import com.btrs.service.util.DBConnectionI;


public class GPSDAO implements GPSDAOI 
{

	static Connection myConn = null;
	static Statement stmt = null;
	static PreparedStatement pStmt = null;
	static ResultSet myRslt = null;
	
	
	

	
	
	//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< COUNTRIES >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>	

	
	
	public List<CountryTO> getCountries(CountryTO countryTO) throws MVCApplicationException
	{
		
		DBConnectionI db = new DBConnection();
		List<CountryTO> countryList = new ArrayList<CountryTO>();
		try
		{
			myConn = db.getMySQLConnection();
			
			stmt = myConn.createStatement();
			myRslt = stmt.executeQuery(QueryConstants.GET_COUNTRIES);
			
			
			while(myRslt.next())
			{
				CountryTO  countryTo = new CountryTO();
				countryTo.setCountryId((String)myRslt.getString("country_id"));
				countryTo.setCountryName((String)myRslt.getString("country_name"));
				
				countryList.add(countryTo);
				
			}
		}
		catch(SQLException e)
		{
			throw new MVCApplicationException();
		}
		
		
		return countryList;
		
	}
	
	
	//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< STATES >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>	

	
	
	public List<StateTO> getStates(StateTO stateTO) throws  MVCApplicationException
	{
		
		DBConnection db = new DBConnection();
		List<StateTO> statesList = new ArrayList<>();
		
		try
		{
			myConn = db.getMySQLConnection();
			
			stmt = myConn.createStatement();
			myRslt = stmt.executeQuery(QueryConstants.GET_STATES);
			
			/*pStmt = myConn.prepareStatement("Select * from states where country_id = '?'");
			pStmt.setString(1, stateTO.getCountry().getCountryId());
			myRslt = pStmt.executeQuery();*/
			
			while(myRslt.next())
			{
				stateTO = new StateTO();
				stateTO.setStateId((String)myRslt.getString("state_id"));
				stateTO.setStateName((String)myRslt.getString("state_name"));
				
				statesList.add(stateTO);
			}
			
		}
		catch(SQLException e)
		{
			throw new MVCApplicationException();
		}
		
		
		
		
		return statesList;
		
	}
	
	
	
	
	//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< CITIES >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>	

	
	
	
	public List<CityTO> getCities(CityTO cityTO) throws  MVCApplicationException
	{
		
		DBConnection db = new DBConnection();
		List<CityTO> cityList = new ArrayList<>();
		
		try
		{
			myConn = db.getMySQLConnection();
			
			stmt = myConn.createStatement();
			myRslt = stmt.executeQuery(QueryConstants.GET_CITIES);
			
	/*		pStmt = myConn.prepareStatement("Select * from cities where country_id = '?' and state_id = '?'");
			pStmt.setString(1, cityTO.getCountry().getCountryId());
			pStmt.setString(2, cityTO.getState().getStateId());
			myRslt = pStmt.executeQuery();*/
			
			while(myRslt.next())
			{
				cityTO = new CityTO();
				cityTO.setCityId((String)myRslt.getString("city_id"));
				cityTO.setCityName((String)myRslt.getString("city_name"));
				
				cityList.add(cityTO);
			}
		}
		catch(SQLException e)
		{
			throw new MVCApplicationException();
		}
		
		
		
		
		return cityList;
		
	}
	
	
	
	
	
	
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< ZIP CODES >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>	
	
	
	
	public List<ZipCodeTO> getZipCodes(ZipCodeTO zipCodeTO) throws  MVCApplicationException
	{
		
		DBConnection db = new DBConnection();
		List<ZipCodeTO> zipCodeList = new ArrayList<>();
		
		try
		{
			myConn = db.getMySQLConnection();
			
			stmt = myConn.createStatement();
			myRslt = stmt.executeQuery(QueryConstants.GET_ZIPCODES);
			
			/*pStmt = myConn.prepareStatement("Select * from city_pincode where city_id = '?'");
			pStmt.setString(1, zipCodeTO.getCity().getCityId());
			myRslt = pStmt.executeQuery();*/
			
			while(myRslt.next())
			{
				zipCodeTO = new ZipCodeTO();
				zipCodeTO.setZipCodeId((String) myRslt.getString("location_id"));
				zipCodeTO.setZipCode((String) myRslt.getString("zip_code"));
				
				zipCodeList.add(zipCodeTO);
			}
			
		}
		catch(SQLException e)
		{
			throw new MVCApplicationException();
		}
		
		
		
		return zipCodeList;
		
	}
	
	
	
}
