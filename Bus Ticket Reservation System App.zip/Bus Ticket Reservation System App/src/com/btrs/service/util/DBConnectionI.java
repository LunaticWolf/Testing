package com.btrs.service.util;

import java.sql.Connection;

import com.btrs.service.exception.MVCApplicationException;

public interface DBConnectionI 
{
	public Connection getMySQLConnection() throws MVCApplicationException;
}
