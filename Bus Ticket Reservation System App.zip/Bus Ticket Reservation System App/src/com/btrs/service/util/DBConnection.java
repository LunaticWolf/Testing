package com.btrs.service.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.btrs.service.exception.MVCApplicationException;


public class DBConnection  implements DBConnectionI
{
	
	static String user = null;
	static String password = null;
	static String url = null;
	static String driver = null;
	
	static Connection myConn = null;
	
	
	 
	public  Connection getMySQLConnection() throws MVCApplicationException
	{
		ResourceBundle bundle = ResourceBundle.getBundle("mysql-db");
		
		user = bundle.getString("db.username");
		password = bundle.getString("db.password");
		url = bundle.getString("db.url");
		driver = bundle.getString("db.driver");
			
		try
		{
			Class.forName(driver);
			myConn = DriverManager.getConnection(url, user, password);
		}
		catch(ClassNotFoundException | SQLException e)
		{
			throw new MVCApplicationException(e);
		}
		
		return myConn;
	
	}	
}
