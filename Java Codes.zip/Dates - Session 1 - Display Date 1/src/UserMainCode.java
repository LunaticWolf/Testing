import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class UserMainCode 
{

	public  static void displayDate(String date) throws ParseException
	{
		DateFormat df = new SimpleDateFormat("MMMM dd,yyyy");
		Date convertedDate1 = df.parse(date);
	
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String convertedDate = sdf.format(convertedDate1);
		
		System.out.println(convertedDate);
		
	}
	
}
