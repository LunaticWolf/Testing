import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class UserMainCode 
{

	public static void displayDateTime(String date) throws ParseException
	{
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date convertedDate = sdf.parse(date);
		
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy, H:mm:ss");
		 
		System.out.println(df.format(convertedDate));
		
	}
	
}
