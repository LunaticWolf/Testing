import java.text.ParseException;
import java.util.Scanner;


public class Main 
{

	public static void main(String[] args) throws ParseException 
	{
	
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter String in this format(yyyy-MM-DD HH:mm:ss)");
		String date = scanner.nextLine();
		
		UserMainCode.displayDateTime(date);
		
	}
	
}
