
public class PlayerBO 
{
	
	static String player = "Player";
	static String country = "Country";
	static String skills = "Skill";
	
	public void menu()
	{
		System.out.println("Menu:");
		System.out.println("1.View details\n2.Filter players with skill\n3.Exit");
	}
	
	public void display()
	{
		System.out.println(String.format("%-15s %-15s %-15s", player, country, skills));
	}
	
	
	public void viewDetails(Player[] playerList)
	{
		display();
		for(int i=0;i<playerList.length;i++)
		{
			System.out.println(playerList[i].toString());
		}
		
	}
	
	public 	void printPlayerDetailsWithSkill(Player[] playerList, String skill)
	{
		display();
		int count=0;
		for(int i=0;i<playerList.length;i++)
		{
			if(playerList[i].getSkill().getSkillName().equals(skill))
			{
				count++;
				System.out.println(playerList[i].toString());
			}
			
		} 
		if(count==0)
			System.out.println("Skill not found");
	}
}
