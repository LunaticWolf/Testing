
import java.util.Scanner;


public class Main 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		PlayerBO playerBO = new PlayerBO();
		
		System.out.println("Enter number of Players");
		int n = scanner.nextInt();

		
		Player[] player = new Player[n];
		scanner.nextLine();
		for(int i=0;i<n;i++)
		{
			int j=i+1;
			System.out.println("Enter player " + j + " details:");
			
			System.out.println("Enter player name");
			String name = scanner.nextLine();
			
			System.out.println("Enter country name");
			String country = scanner.nextLine();
			
			System.out.println("Enter skill");
			Skill skill = new Skill(scanner.nextLine());
			
			player[i] = new Player(name, country, skill); 
		}
		
		
		boolean isContinue=true;
		while(isContinue)
		{
		
			playerBO.menu();
			int choice = Integer.parseInt(scanner.nextLine());
			switch(choice)
			{
				case 1: playerBO.viewDetails(player);
					break;
				
				case 2: System.out.println("Enter skill");
						String skill = scanner.nextLine();
						playerBO.printPlayerDetailsWithSkill(player, skill);
					break;
					
				case 3: isContinue = false;
					break;
			}
		}
		
		scanner.close();
	}
}
