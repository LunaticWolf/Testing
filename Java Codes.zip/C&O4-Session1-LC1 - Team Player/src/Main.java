import java.util.Scanner;


public class Main 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		TeamBO teamBO = new TeamBO();
		PlayerBO playerBO = new PlayerBO();
		
		
		System.out.println("Enter the team count");
		int teamCount = Integer.parseInt(scanner.nextLine());
		
		Team[] team = new Team[teamCount];		
		for(int i=0;i<team.length;i++)
		{
			int j=i+1;
			System.out.println("Enter team " + j + " details");
			String data = scanner.nextLine();
			
			//Adding team info -> team-home
			team[i] =teamBO.createTeam(data);
			
		}
		
		
		
		System.out.println("Enter the player count");
		int playerCount = Integer.parseInt(scanner.nextLine());
	
		Player[] player = new Player[playerCount];
		
		
		for(int i=0;i<player.length;i++)
		{
			int j=i+1;
			System.out.println("Enter player " + j + " details");
			String details = scanner.nextLine();
			
			//Adding Player Info -> name-team
			player[i] = playerBO.createPlayer(details, team);
		}
		
		System.out.println("Enter the player name for which you need to find the team name");
		String playername = scanner.nextLine();
		
		System.out.println(playername + " belongs to " + playerBO.findTeamName(player, playername));
		
		
		System.out.println("Enter 2 player names");
		String playername1 = scanner.nextLine();
		String playername2 = scanner.nextLine();
		
		boolean result =playerBO.findWhetherPlayersAreInSameTeam(player, playername1, playername2);
		if (result)
		{
			System.out.println("The 2 player are in the same team");
		}
		else
		{
			System.out.println("The 2 player are in the different teams");
		}
		
		
		scanner.close();
		
	}
}
