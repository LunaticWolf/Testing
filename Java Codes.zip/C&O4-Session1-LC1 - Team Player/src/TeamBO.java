
public class TeamBO 
{
	public Team createTeam(String data)
	{
		String[] s = data.split(",");
		String name = s[0];
		String home = s[1];
		Team team=new Team(name, home);
		return team;
	}
}
