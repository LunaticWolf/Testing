public class PlayerBO {

	public Player createPlayer(String data, Team[] teamList) {
		String[] details = data.split(",");

		String playerName = details[0];
		String teamName = details[1];
		Player player = null;
		for (int i = 0; i < teamList.length; i++) {
			if (teamList[i].getName().equals(teamName)) {
				player = new Player(playerName, teamList[i]);
			}
		}
		return player;
	}

	public String findTeamName(Player[] playerList, String playername) {
		String result="";
		for (int i = 0; i < playerList.length; i++) {
			if (playerList[i].getName().equals(playername)) {
				result= playerList[i].getTeam().getName();
				
			}

		}
		return result;

	}

	public Boolean findWhetherPlayersAreInSameTeam(Player[] playerList,
			String playername1, String playername2) 
	{
		String team1 = null;
		String team2 = null;
		for (int i = 0; i < playerList.length; i++) {

			if (playerList[i].getName().equalsIgnoreCase(playername1))
				team1 = playerList[i].getTeam().getName();

			if (playerList[i].getName().equalsIgnoreCase(playername2))
				team2 = playerList[i].getTeam().getName();

		}

		boolean result =team1.equals(team2);
			

		return result;

	}
}
