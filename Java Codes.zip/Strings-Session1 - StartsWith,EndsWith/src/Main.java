import java.util.Scanner;


public class Main 
{
public static void main(String[] args) 
{
	Scanner scanner = new Scanner(System.in);

	System.out.println("Enter the number of players");
	int nPlayers = Integer.parseInt(scanner.nextLine());
	
	String[] players = new String[nPlayers];
	String[] displayPlayers = new String[nPlayers];
	System.out.println("Enter the player name");
	System.out.println("Player name starting with 'M' or Ending with 'a'");
	for(int i=0,j=0;i<players.length;i++)
	{
		players[i] = scanner.nextLine();
		if(players[i].substring(0).startsWith("M") || players[i].substring(0).endsWith("a"))
		{
			displayPlayers[j] = players[i];
			j++;
		}
	}
	
	for(int i=0;i<displayPlayers.length;i++)
		if(displayPlayers[i]!=null)
		System.out.println(displayPlayers[i]);
	
	scanner.close();
}

}
