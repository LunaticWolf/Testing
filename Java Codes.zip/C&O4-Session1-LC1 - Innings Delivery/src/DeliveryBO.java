
public class DeliveryBO 
{
	 //static Innings[] inningsList = new Delivery[2];
	
	public Delivery createDelivery(String data, Innings[] inningsList)
	{
		String[] details = data.split(",");
		
		long deliveryNumber = Long.parseLong(details[0]);
		String batsman = details[1].toString();
		String bowler = details[2].toString();
		long runs = Long.parseLong(details[3]);
		Long inningsNumber = Long.parseLong(details[4]);
		
		Delivery delivery = null;
		
		for(int i=0;i<inningsList.length;i++)
		{
			if(inningsList[i].getInningsNumber() == inningsNumber)
			{
				delivery = new Delivery(deliveryNumber, batsman, bowler, runs, inningsNumber, inningsList[i]);
				
			}
		}
		
		return delivery;
	}	
		

	
	public String findInningsNumber(Delivery[] deliveryList, long deliveryNumber)
	{
		
		
		long inningsDeliveryNumber=0;
		for(int i=0;i<deliveryList.length;i++)
		{
		
			if(deliveryList[i].getDeliveryNumber() == deliveryNumber)
			{
				inningsDeliveryNumber = deliveryList[i].getInningsNumber();
		
			}
		}
		return Long.toString(inningsDeliveryNumber);
	}

	

}	
	

	

