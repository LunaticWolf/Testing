import java.util.Scanner;



public class Main {

	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		
		//Access Methods
		InningsBO inningsBO = new InningsBO();
		DeliveryBO deliveryBO = new DeliveryBO();
		
		
		System.out.println("Enter the number of innings");
		int countInnings = Integer.parseInt(scanner.nextLine());
		
		//Inherits
		
		Innings[] innings = new Innings[countInnings];
		
		//Innings[] innings = new Innings[countInnings];
		for(int i=0;i<innings.length;i++)
		{
			int j=i+1;
			System.out.println("Enter innings " + j + " details");
			String inningsDetails = scanner.nextLine();
			
			innings[i] = inningsBO.createInnings(inningsDetails);
		}
		
		
		
		
		System.out.println("Enter the number of deliveries");
		int countDeliveries = Integer.parseInt(scanner.nextLine());
		
		Delivery[] delivery = new Delivery[countDeliveries];
		for(int i =0;i<delivery.length;i++)
		{
			int j=i+1;
			System.out.println("Enter innings " + j + " details");
			String deliveryDetails = scanner.nextLine();
			
			delivery[i] = deliveryBO.createDelivery(deliveryDetails, innings);

		}
		
		
		System.out.println("Enter the delivery number for which you need to find the innings number");
		long deliveryNumber = scanner.nextLong();
		
	
		
		String result = deliveryBO.findInningsNumber(delivery, deliveryNumber);
		System.out.println("Innings : " + result);
		scanner.close();
		
	}

}
