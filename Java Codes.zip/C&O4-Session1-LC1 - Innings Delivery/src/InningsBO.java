
public class InningsBO 
{

	public Innings createInnings(String data)
	{
		String[] details = data.split(",");
		
		long inningsNumber = Long.parseLong(details[0]);
		String battingTeam = details[1];
		
		return new Innings(inningsNumber, battingTeam);
		
	}
	
}
