
public class UserMainCode 
{
	public static boolean validateOver(String score)
	{
		boolean valid = false;
		
		int wickets = 0;
		int noBalls = 0;
	
		if(score.length()==6)
		{
			for(int i=0;i<score.length();i++)
			{
				if(score.charAt(i)=='W')
					wickets+=1;
				if(score.charAt(i)=='N')
					noBalls+=1;
			}
		}
		
		if(wickets>=1 && noBalls==0)
			valid = true;
		
		return valid;
	}
}
