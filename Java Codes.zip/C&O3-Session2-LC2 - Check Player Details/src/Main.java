import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		
		Player[] player = new Player[2];
		
		for(int i=0;i<2;i++)
		{
			int j=i+1;
			System.out.println("Enter the player " + j + " details");
			System.out.println("Enter the player name");
			String name = scanner.nextLine();
		
			System.out.println("Enter the country name");
			String country = scanner.nextLine();
		
			System.out.println("Enter the skill");
			String skill = scanner.nextLine();
		
			player[i] = new Player(name, country, skill);
		
			System.out.println(player[i].toString());
		}
		if(player[0].equals(player[1])){
		System.out.println("Both the player details are same.");
		}
		else {
			System.out.println("Both the player details are not same.");
		}
		
		}
}
