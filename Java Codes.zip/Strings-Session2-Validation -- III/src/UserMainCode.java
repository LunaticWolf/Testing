
public class UserMainCode 
{
	public static boolean validatePlayer(String playerName, String countryName, String playerCountry)
	{
		boolean validity = false;
		boolean check1 = false;
		boolean check2 = false;
		String[] splitDetails = playerCountry.split("#");
		
		//---------------------------------------------------------- PART - 1 ---------------------------------------------------------
		if(splitDetails[0].equals(playerName))
			check1=true;

		
		
		//----------------------------------------------------------- PART - 2 --------------------------------------------------------
		StringBuilder sb = new StringBuilder();
		String initials = null;
		if(countryName.contains(" "))
		{		
			String[] countryDetails = countryName.split(" ");
			
			for(int i=0;i<countryDetails.length;i++)
				{
					sb.append(countryDetails[i].charAt(0));
				}	
		}
		else
				sb.append(countryName.charAt(0)).append(countryName.charAt(1)).append(countryName.charAt(2)).toString();
			
		
		initials = sb.toString().toUpperCase();
		
		
		
		
		if(splitDetails[1].equals(initials))
			check2 = true;
		if(check1 && check2)
			validity = true;
		
		
		return validity;
	}
}
