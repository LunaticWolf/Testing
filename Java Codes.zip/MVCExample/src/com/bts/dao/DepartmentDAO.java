package com.bts.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bts.constants.QueryConstant;
import com.bts.exception.MVCApplicationException;
import com.bts.model.DepartmentTO;
import com.bts.model.JobTO;
import com.bts.util.DataManager;

public class DepartmentDAO 
{
	private static Connection myConn;
	private static Statement stmt;
	private static ResultSet myResultSet;
	
	
	public static List<DepartmentTO> getAllDepartments() throws MVCApplicationException 
	{
		List<DepartmentTO> departmentList = new ArrayList<>();
		try
		{
			myConn = DataManager.getConnection();
			stmt = myConn.createStatement();
			myResultSet = stmt.executeQuery(QueryConstant.GET_ALL_DEPARTMENTS_QUERY);
			
			
			while(myResultSet.next())
			{
				int departmentNumber = myResultSet.getInt("dept_no");
				String departmentName = myResultSet.getString("dept_name");
				String departmentLocation = myResultSet.getString("dept_loc");
				DepartmentTO departmentTO = new DepartmentTO(departmentNumber, departmentName, departmentLocation);
				departmentList.add(departmentTO);
			}
			return departmentList;
			
		}
		catch(ClassNotFoundException | SQLException e)
		{
				throw new MVCApplicationException(e);
		}
		
		finally
		{
			
			closeConnection();
		}
		
		
	}
	
	private static void closeConnection() throws  MVCApplicationException
	{
		try
		{
		if(myConn!=null)
			myConn.close();
		}
		catch(SQLException e)
		{
			throw new MVCApplicationException(e);		
			}
	}
	
}
