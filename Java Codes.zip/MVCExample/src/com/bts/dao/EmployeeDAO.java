package com.bts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.sql.Date;

import java.util.Map;

import jdk.xml.internal.HashMap;

import com.bts.constants.QueryConstant;
import com.bts.exception.MVCApplicationException;

import com.bts.model.EmployeeTO;
import com.bts.util.DataManager;

public class EmployeeDAO 
{
	private static Connection myConn;
	private static PreparedStatement pStmt;
	private static Statement stmt;
	private static ResultSet myResultSet;
	boolean result=false;
	
	public boolean addEmployee(EmployeeTO employeeTO) throws MVCApplicationException
	{
		try
		{
			myConn = DataManager.getConnection();
			pStmt = myConn.prepareStatement(QueryConstant.ADD_EMPLOYEE_QUERY);
			
			pStmt.setString(1, employeeTO.getEmployeeNumber());
			pStmt.setString(2, employeeTO.getEmployeeName());
			pStmt.setInt(3, employeeTO.getJobId());
			pStmt.setString(4, employeeTO.getMgr());
			
			
			pStmt.setDate(5, new Date(employeeTO.getHiredate().getTime()));
			pStmt.setDouble(6, employeeTO.getSalary());
			pStmt.setDouble(7, employeeTO.getComm());
			pStmt.setInt(8, employeeTO.getDeptNumber());
			
			int n = pStmt.executeUpdate();
			result = (n==1)?true:false;
		}
		catch(ClassNotFoundException | SQLException e)
		{
			throw new MVCApplicationException(e);
		}
		return result;
	}
	
	
	
	
	
	
	
	public static Map<String,String> getAllEmployee() throws MVCApplicationException 
	{
		Map<String,String> employeeMap = new HashMap<>();
		try
		{
			myConn = DataManager.getConnection();
			stmt = myConn.createStatement();
			myResultSet = stmt.executeQuery(QueryConstant.GET_ALL_EMPLOYEE_QUERY);
			
			
			while(myResultSet.next())
			{
				String empNo = myResultSet.getString("emp_no");
				String empName = myResultSet.getString("dept_name");
				
				employeeMap.put(empNo, empName);
			}
			return employeeMap;
			
		}
		catch(ClassNotFoundException | SQLException e)
		{
				throw new MVCApplicationException(e);
		}
		
		finally
		{
			
			closeConnection();
		}
		
		
	}
	
	private static void closeConnection() throws  MVCApplicationException
	{
		try
		{
		if(myConn!=null)
			myConn.close();
		}
		catch(SQLException e)
		{
			throw new MVCApplicationException(e);		
			}
	}
	
}
