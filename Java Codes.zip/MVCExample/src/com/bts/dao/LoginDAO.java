package com.bts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bts.constants.QueryConstant;
import com.bts.exception.MVCApplicationException;
import com.bts.model.UserTO;
import com.bts.util.DataManager;

public class LoginDAO 
{
	private static Connection myConn;
	private static PreparedStatement pStmt;
	private static ResultSet myResultSet;
	
	
	public boolean validateUser(UserTO userTO) throws MVCApplicationException
	{
		boolean result = false;
		
		try 
		{
			myConn = DataManager.getConnection();
		
			pStmt = myConn.prepareStatement(QueryConstant.VALID_USER_QUERY);
			pStmt.setString(1, userTO.getUserName());
			myResultSet =  pStmt.executeQuery();
			
			if(myResultSet.next())
			{
				String password = myResultSet.getString("password");
				if(password.equals(userTO.getPassword()))
				{
					result = true;
				}
			}
			
			
		}
		catch (ClassNotFoundException | SQLException e) 
		{
			throw new MVCApplicationException(e);
		}
		return result;
	}
	
	
	
}
