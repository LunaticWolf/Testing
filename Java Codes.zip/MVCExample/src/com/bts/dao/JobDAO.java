package com.bts.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.internal.compiler.flow.FinallyFlowContext;

import com.bts.constants.QueryConstant;
import com.bts.exception.MVCApplicationException;
import com.bts.model.*;
import com.bts.util.DataManager;

public class JobDAO 
{
	private static Connection myConn;
	private static Statement stmt;
	private static ResultSet myResultSet;
	
	public static List<JobTO> getAllJobs() throws MVCApplicationException
	{
		List<JobTO> jobList = new ArrayList<>();
		try
		{
			myConn = DataManager.getConnection();
			stmt = myConn.createStatement();
			myResultSet = stmt.executeQuery(QueryConstant.GET_ALL_JOBS_QUERY);
			
			
			while(myResultSet.next())
			{
				int jobId = myResultSet.getInt("job_id");
				String jobName = myResultSet.getString("job_name");
				JobTO jobTO = new JobTO(jobId,jobName);
				jobList.add(jobTO);
			}
			return jobList;
			
		}
		catch(ClassNotFoundException | SQLException e)
		{
				throw new MVCApplicationException(e);
		}
		
		finally
		{
			closeConnection();
		}
		
		
	}
	
	private static void closeConnection() throws MVCApplicationException
	{
		try
		{
		if(myConn!=null)
			myConn.close();
		}
		catch(SQLException e)
		{
			throw new MVCApplicationException(e);
		}
	}
	
}
