package com.bts.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DataManager 
{
	
	public static Connection getConnection() throws SQLException, ClassNotFoundException
	{
		ResourceBundle rb = ResourceBundle.getBundle("db");
		
		String userName = rb.getString("db.username");
		String password = rb.getString("db.password");
		String url = rb.getString("db.url");
		
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection myConn = DriverManager.getConnection(url,userName,password);
		return myConn;
		
	}
}
