package com.bts.bo;

import com.bts.constants.ErrorConstant;
import com.bts.dao.LoginDAO;
import com.bts.exception.BusinessException;
import com.bts.exception.MVCApplicationException;
import com.bts.model.UserTO;

public class LoginBO 
{
	public boolean validateLogin(UserTO userTO) throws BusinessException, MVCApplicationException
	{
		String userName = userTO.getUserName();
		String password = userTO.getPassword();
		
		if(userName.isEmpty() || password.isEmpty())
		{
			throw new BusinessException(ErrorConstant.EMPTY_USERNAME);
		}
		
		LoginDAO loginDao = new LoginDAO();
		boolean result = loginDao.validateUser(userTO);
		if(result==false)
		{
			throw new BusinessException(ErrorConstant.INVALID_USERNAME);
		}
		
		
		return result;
	}

}
