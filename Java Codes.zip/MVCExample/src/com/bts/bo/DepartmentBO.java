package com.bts.bo;

import java.sql.SQLException;
import java.util.List;

import com.bts.dao.DepartmentDAO;
import com.bts.dao.JobDAO;
import com.bts.exception.MVCApplicationException;
import com.bts.model.DepartmentTO;
import com.bts.model.JobTO;

public class DepartmentBO 
{
	
		public List<DepartmentTO> getAllDepartments() throws MVCApplicationException
		{
			
			List<DepartmentTO> departmentList = DepartmentDAO.getAllDepartments();
			
			return departmentList;
			
		}
	
}
