package com.bts.bo;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.bts.dao.EmployeeDAO;
import com.bts.exception.MVCApplicationException;
import com.bts.model.EmployeeTO;
import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

public class EmployeeBO 
{
	public boolean addEmployee(EmployeeTO employeeTO) throws MVCApplicationException, java.text.ParseException
	{
		EmployeeDAO employeeDAO = new EmployeeDAO();
		
		int jobId =  Integer.parseInt(employeeTO.getEmpJobId());
		double salary =  Integer.parseInt(employeeTO.getEmpSalary());
		double comm =  Integer.parseInt(employeeTO.getEmpComm());
		int deptNumber =  Integer.parseInt(employeeTO.getEmpDeptNumber());
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		
		try
		{
			Date hiredate = sdf.parse(employeeTO.getEmpHiredate());
		}
		catch(ParseException e)
		{
			throw new MVCApplicationException(e);
		}
		
		if("-".equals(employeeTO.getMgr()))
				employeeTO.setMgr(null);
		
		
		employeeTO.setSalary(salary);
		employeeTO.setJobId(jobId);
		employeeTO.setComm(comm);
		employeeTO.setDeptNumber(deptNumber);
		
		
		
		return employeeDAO.addEmployee(employeeTO);
		
	}
}
