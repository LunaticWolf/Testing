package com.bts.bo;


import java.util.List;

import com.bts.dao.JobDAO;
import com.bts.exception.MVCApplicationException;
import com.bts.model.JobTO;

public class JobBO 
{
	public List<JobTO> getAllJobs() throws MVCApplicationException
	{
		
		List<JobTO> jobList = JobDAO.getAllJobs();
		
		return jobList;
		
	}
}
