package com.bts.constants;

public class ErrorConstant {

	public static final String EMPTY_USERNAME = "Empty Username/Password";
	public static final String INVALID_USERNAME = "Invalid Username/Password";
	public static final String LOGIN_PAGE = "login.jsp";
	public static final String HOME_PAGE = "home.jsp";

}
