package com.bts.constants;

public class SuccessConstant {

	public static final String HOME_PAGE = "home.jsp";
	public static final String ADD_EMPLOYEE_PAGE = "add-employee.jsp";
	

}
