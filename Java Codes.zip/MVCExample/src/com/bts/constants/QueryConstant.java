package com.bts.constants;

public class QueryConstant {

	public static final String VALID_USER_QUERY = "Select password from login where username=?";
	public static final String GET_ALL_JOBS_QUERY = "Select * from Job";
	public static final String GET_ALL_DEPARTMENTS_QUERY = "select * from dept";
	public static final String GET_ALL_EMPLOYEE_QUERY = "select emp_no,emp_name from emp";
	public static final String ADD_EMPLOYEE_QUERY = "insert into emp values(?,?,?,?,?,?,?,?)";

}
