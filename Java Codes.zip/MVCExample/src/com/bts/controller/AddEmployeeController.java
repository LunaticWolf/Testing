package com.bts.controller;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bts.bo.EmployeeBO;
import com.bts.exception.MVCApplicationException;
import com.bts.model.EmployeeTO;


public class AddEmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public AddEmployeeController() 
    {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String employeeName = request.getParameter("empname");
		String empJobId = request.getParameter("jobId");
		String mgr = request.getParameter("mgr");
		String empHiredate = request.getParameter("empHiredate");;
		String empSalary = request.getParameter("empSalary");;
		String empComm = request.getParameter("empComm");;
		String empDeptNumber = request.getParameter("empDeptNumber");;
		
		EmployeeTO employeeTO = new EmployeeTO(null, employeeName, mgr, empJobId, empSalary, empComm, empHiredate, empDeptNumber);
	
		EmployeeBO employeeBO = new EmployeeBO();
		try {
			employeeBO.addEmployee(employeeTO);
		} catch (MVCApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
