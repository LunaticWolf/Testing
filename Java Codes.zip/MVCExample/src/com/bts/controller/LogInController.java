package com.bts.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bts.bo.LoginBO;
import com.bts.constants.ErrorConstant;
import com.bts.constants.SuccessConstant;
import com.bts.exception.BusinessException;
import com.bts.exception.MVCApplicationException;
import com.bts.model.UserTO;



public class LogInController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String userName = request.getParameter("username");
		String password = request.getParameter("password");
		UserTO userTo = new UserTO(userName, password);
		
		
		LoginBO loginBo = new LoginBO();
		RequestDispatcher rd = request.getRequestDispatcher(SuccessConstant.HOME_PAGE);
		
		try
		{
			boolean result = loginBo.validateLogin(userTo);
			HttpSession session = request.getSession();
			session.setAttribute("username", userName);
			rd.forward(request, response);
		}
		catch(MVCApplicationException e)
		{
			rd = request.getRequestDispatcher(ErrorConstant.LOGIN_PAGE);
			request.setAttribute("errorMsg1", e.getMessage());
			System.out.println(e.getMessage());
			rd.forward(request, response);
		}
		catch(BusinessException e)
		{
			rd = request.getRequestDispatcher(ErrorConstant.LOGIN_PAGE);
			request.setAttribute("errorMsg2", e.getMessage());
			rd.forward(request, response);
		}
		
		
		
	}

}
