package com.bts.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bts.bo.DepartmentBO;
import com.bts.bo.JobBO;
import com.bts.constants.ErrorConstant;
import com.bts.constants.SuccessConstant;
import com.bts.exception.MVCApplicationException;
import com.bts.model.DepartmentTO;
import com.bts.model.JobTO;


public class EmployeeController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
  
    public EmployeeController() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		JobBO jobBO =  new JobBO();
		DepartmentBO departmentBO = new DepartmentBO();
		RequestDispatcher rd = request.getRequestDispatcher(SuccessConstant.ADD_EMPLOYEE_PAGE);
		try
		{
			List<JobTO> jobList = jobBO.getAllJobs();
			if(jobList!=null)
			{	//System.out.println("Got Jobs" + jobList.size());
			request.setAttribute("JOBLIST", jobList);
			}
			List<DepartmentTO> departmentList = departmentBO.getAllDepartments();
			if(departmentList!=null)
			{	//System.out.println("Got DEps"+ departmentList.size());
			request.setAttribute("DEPARTMENTLIST", departmentList);
			}
			
			if(request.getAttribute("DEPARTMENTLIST")!=null)
			{
				System.out.println("Got DEps"+ departmentList.size());
			}
			
			rd.forward(request, response);
			
		}
		catch(MVCApplicationException e)
		{
			rd = request.getRequestDispatcher(ErrorConstant.HOME_PAGE);
			request.setAttribute("errorMsg", e.getMessage());
			rd.forward(request, response);
		}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
