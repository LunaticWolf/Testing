package com.bts.model;

public class DepartmentTO 
{
	private int deptNumber;
	private String departmentName;
	private String location;
	
	
	public DepartmentTO() {}
	
	public DepartmentTO(int deptNumber, String departmentName, String location) {
		super();
		this.deptNumber = deptNumber;
		this.departmentName = departmentName;
		this.location = location;
	}
	
	
	public int getDeptNumber() {
		return deptNumber;
	}
	public void setDeptNumber(int deptNumber) {
		this.deptNumber = deptNumber;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	
	
}
