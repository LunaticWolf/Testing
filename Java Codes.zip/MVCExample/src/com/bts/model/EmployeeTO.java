package com.bts.model;

import java.util.Date;

public class EmployeeTO 
{
	private String employeeNumber;
	private String employeeName;
	private String mgr;
	
	
	private int JobId;
	private double salary;
	private double Comm;
	private Date hiredate; 
	private int deptNumber;
	
	
	private String empJobId;
	private String empSalary;
	private String empComm;
	private String empHiredate;
	private String empDeptNumber;
	
	
	
	public EmployeeTO() {}



	public EmployeeTO(String employeeNumber, String employeeName, String mgr,
			String empJobId, String empSalary, String empComm,
			String empHiredate, String empDeptNumber) {
		super();
		this.employeeNumber = employeeNumber;
		this.employeeName = employeeName;
		this.mgr = mgr;
		this.empJobId = empJobId;
		this.empSalary = empSalary;
		this.empComm = empComm;
		this.empHiredate = empHiredate;
		this.empDeptNumber = empDeptNumber;
	}



	public String getEmployeeNumber() {
		return employeeNumber;
	}



	public void setEmployeeNumber(String employeeNumber) {
		this.employeeNumber = employeeNumber;
	}



	public String getEmployeeName() {
		return employeeName;
	}



	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}



	public String getMgr() {
		return mgr;
	}



	public void setMgr(String mgr) {
		this.mgr = mgr;
	}



	public int getJobId() {
		return JobId;
	}



	public void setJobId(int jobId) {
		JobId = jobId;
	}



	public double getSalary() {
		return salary;
	}



	public void setSalary(double salary) {
		this.salary = salary;
	}



	public double getComm() {
		return Comm;
	}



	public void setComm(double comm) {
		Comm = comm;
	}



	public Date getHiredate() {
		return hiredate;
	}



	public void setHiredate(Date hiredate) {
		this.hiredate = hiredate;
	}



	public int getDeptNumber() {
		return deptNumber;
	}



	public void setDeptNumber(int deptNumber) {
		this.deptNumber = deptNumber;
	}



	public String getEmpJobId() {
		return empJobId;
	}



	public void setEmpJobId(String empJobId) {
		this.empJobId = empJobId;
	}



	public String getEmpSalary() {
		return empSalary;
	}



	public void setEmpSalary(String empSalary) {
		this.empSalary = empSalary;
	}



	public String getEmpComm() {
		return empComm;
	}



	public void setEmpComm(String empComm) {
		this.empComm = empComm;
	}



	public String getEmpHiredate() {
		return empHiredate;
	}



	public void setEmpHiredate(String empHiredate) {
		this.empHiredate = empHiredate;
	}



	public String getEmpDeptNumber() {
		return empDeptNumber;
	}



	public void setEmpDeptNumber(String empDeptNumber) {
		this.empDeptNumber = empDeptNumber;
	}
	
	
	
	
}
