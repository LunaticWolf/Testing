import java.util.Scanner;


public class Main 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		
		String playerName = scanner.nextLine();
		if(UserMainCode.validatePlayer(playerName))
			System.out.println("Valid");
		else
			System.out.println("Invalid");
		
		
		scanner.close();
	}
}
