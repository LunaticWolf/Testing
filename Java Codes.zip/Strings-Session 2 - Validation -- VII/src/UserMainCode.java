
public class UserMainCode 
{
	public static boolean validatePlayer(String playerName)
	{
		boolean validity = true;
	
		for(int i=0;i<playerName.length();i++)
		{
			
			if((playerName.charAt(i)=='a'))
			{
				if(i%2==0)
				 {
					validity = false;
					break;
				 }
			}
		
		}
		
		
		return validity;
	}
}
