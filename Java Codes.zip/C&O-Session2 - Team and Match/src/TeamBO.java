
public class TeamBO 
{
	public Team createTeam(String data,Player[] playerList)
	{
		String[] details = data.split(",");
		
		String teamName = details[0];
		String playerName = details[1];
		
		Team team = null;
		for(int i=0;i<playerList.length;i++)
		{
			if(playerList[i].getName().equals(playerName))
			{
				team = new Team(teamName, playerList[i]);
			}
		}
		
		
		return team;
	}
}
