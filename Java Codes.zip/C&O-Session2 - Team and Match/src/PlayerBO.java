
public class PlayerBO 
{
	public Player createPlayer(String data)
	{
		String[] details = data.split(",");
		String name = details[0];
		String country = details[1];
		String skill = details[2];
		
		Player player = new Player(name, country, skill);
		return player;
		
		
	}
}
