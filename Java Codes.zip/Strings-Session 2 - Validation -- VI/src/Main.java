import java.util.Scanner;


public class Main 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		
		String details = scanner.nextLine();
		UserMainCode.orangeCapDetails(details);
		
		scanner.close();
	}
}
