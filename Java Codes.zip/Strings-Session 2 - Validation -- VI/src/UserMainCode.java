
public class UserMainCode 
{
	public static void orangeCapDetails(String details)
	{
		int breakString = 0;
		int breakString2 = 0;
		for(int i=0;i<details.length();i++)
		{
			if(details.charAt(i)==' ')
			continue;	
			
			if(!(Character.isUpperCase(details.charAt(i))))
			{
				breakString = i;
				break;
				
			}
			
			for(i=breakString;i<details.length();i++)
			{
				if((Character.isAlphabetic(details.charAt(i))))
					continue;
				else
					 breakString2 = i;
			}
		}
		
		
		
		System.out.println(details.substring(0, (breakString-1)));
		System.out.println(details.substring(breakString-1, breakString2-2));
		System.out.println(details.substring(breakString2-2, details.length()));
		
		
		
		
		
	}
}
