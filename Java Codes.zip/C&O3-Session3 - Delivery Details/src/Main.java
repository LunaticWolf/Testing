import java.util.Scanner;


public class Main 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		DeliveryBO deliveryBO = new DeliveryBO();
		
		System.out.println("Enter the number of deliveries");
		int n = scanner.nextInt();
		Delivery[] delivery = new Delivery[n];
		
		scanner.nextLine();
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the over");
			long over = Long.parseLong(scanner.nextLine());
			
			System.out.println("Enter the ball");
			long ball = Long.parseLong(scanner.nextLine());
			
			System.out.println("Enter the batsman");
			String batsman = scanner.nextLine();
			
			System.out.println("Enter the bowler");
			String bowler = scanner.nextLine();
			
			System.out.println("Enter the nonStriker");
			String nonStriker = scanner.nextLine();
			
			delivery[i] = new Delivery(over, ball, batsman, bowler, nonStriker);
			
		}
		
			
			deliveryBO.displayAllDeliveryDetails(delivery);

		scanner.close();
	}
}
