import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.jdbc.DatabaseMetaData;
import com.mysql.jdbc.ResultSetMetaData;


public class Main 
{

	static Connection myConn = null;
	static String Driver = "com.mysql.jdbc.Driver";
	static String url = "jdbc:mysql://localhost:3306/mydb";
	static String userName = "root";
	static String password = "root";
	
	
	static Statement statement = null;
	static ResultSet resultSet = null;
	
	
	public static void main(String[] args) 
	{
		
		try 
		{
			Class.forName(Driver);
			
			myConn= DriverManager.getConnection(url,userName,password);
			
			statement = myConn.createStatement();
			resultSet = statement.executeQuery("Select * from emp1");
			
			java.sql.ResultSetMetaData rsMd = resultSet.getMetaData();
			
			int cols = rsMd.getColumnCount();
			System.out.println("Columns = " + cols );
			
			for(int i=0;i<=cols;i++)
			{
				System.out.println(rsMd.getColumnName(i) + " ");
				System.out.println(rsMd.getColumnTypeName(i) + " ");
				System.out.println(rsMd.getColumnType(i) + " ");
				System.out.println(rsMd.getColumnDisplaySize(i) + " ");
			}
			
			
			
		}	
			
			
			
			
			/*java.sql.DatabaseMetaData meta = myConn.getMetaData();
			System.out.println(meta.getDriverName());
			System.out.println(meta.getURL());
			*/
			
		
		
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch (SQLException e) {
		e.printStackTrace();
		}
	}
}
