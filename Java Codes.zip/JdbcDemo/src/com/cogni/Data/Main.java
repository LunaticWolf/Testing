package com.cogni.Data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.cogni.driver.connection.MySqlConnection;

public class Main 
{
	static Connection connection = null;
	//static Statement statement = null;
	static ResultSet resultSet = null;
	static String query = null;//"select * from emp2";
	static PreparedStatement preparedStatement = null;
	
	
	
	
	//Using Statement alone
	/*public static void main(String[] args) 
	{
		connection = MySqlConnection.MyConnection();
		System.out.println("Connection - " + connection);
	
		int i=0;
		try 
		{
		
			System.out.println(" 1 " + resultSet);
			resultSet = connection.createStatement().executeQuery(query);
		
			while(resultSet.next())
			{
				
				System.out.println("\nEmp No - " + i + ": "  + resultSet.getInt(1));
				System.out.println("\nEmp Name  - " + i +  ": " + resultSet.getString(2));
				i++;
			}
		
	
		}
		
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
	}*/
	
	
	//Prepared Statement - DML
	public static void main(String[] args) 
	{
		
		Scanner scanner = new Scanner(System.in);
		//System.out.println("Enter the Query for Emp1 Table");
		//query = scanner.nextLine();
		
		query = "insert into emp1 values(?,?)";
		
		System.out.println("Execute Query?? ");
		String choice = scanner.nextLine();
		
		connection = MySqlConnection.MyConnection();
		
		try 
		{
			preparedStatement = connection.prepareStatement(query);	
			
			
			while("yes".equalsIgnoreCase(choice))
			{			
				System.out.println("Employee Id - ");
				int emp_id = Integer.parseInt(scanner.nextLine());
				
				System.out.println("Employee Name - ");
				String emp_name = scanner.nextLine();
				
				preparedStatement.setInt(1, emp_id);
				preparedStatement.setString(2, emp_name);
				
				System.out.println(preparedStatement);
				
				//return int value
				if(preparedStatement.executeUpdate()>0)
					System.out.println("Registered");
				else
					System.out.println("Failed");
				
				
				System.out.println("Register Another One??");
				choice = scanner.nextLine();
				if(choice.equalsIgnoreCase("no"))
					break;
			}
			
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		scanner.close();
		
	}
	
	
	
	
	
}
