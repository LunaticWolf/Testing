package com.cogni.driver.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MySqlConnection 
{
	static Connection myConn = null;
	//static String Driver = "com.mysql.jdbc.Driver";
	static String url = "jdbc:mysql://localhost:3306/mydb";
	static String userName = "root";
	static String password = "root";
	
	
	public MySqlConnection(){}
	
	
	public static Connection MyConnection()
	{
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
	
			//Driver driver = new com.mysql.jdbc.Driver();	
			System.out.println("Driver Class Sucessfully  Loaded...");
			System.out.println("Establishing Connection....");
			Thread.sleep(1000);
			
			myConn =DriverManager.getConnection(url,userName,password);
			
			System.out.println("\n\nConnection Established....");
			
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		catch (InterruptedException e) 
		{	
			e.printStackTrace();
		}
		
		return myConn;
	
	}
	
	
	public void CloseConnection()
	{
		try 
		{
			myConn.close();
		}
		catch(SQLException e)
		{
			System.out.println("\n\n\t\tConnection Closed..." );
		}
	}
	
}