import java.util.Scanner;


public class Main 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		
		String city = scanner.nextLine();
		
		if(UserMainCode.validateCity(city))
			System.out.println("Valid");
		else
			System.out.println("Invalid");
		
		
		scanner.close();
	}
}
