public class UserMainCode {
	public static boolean validateCity(String city)
	{
		boolean valid = false;
		
		char[] starCity = city.toCharArray();
		int len =starCity.length-1;
		
		if (city.length()>4)
		{
			if (Character.isLetter(starCity[0])  && Character.isLetter(starCity[1]) && Character.isLetter(starCity[len]) &&Character.isLetter(starCity[len-1]))
			{ 
		     	valid=true;
				for(int i=2;i<starCity.length-2;i++)
				{
					if(starCity[i]!='*')
					{
						valid=false;
						break;
					}
				}
			}
		}
			return valid;
			
	}
}
