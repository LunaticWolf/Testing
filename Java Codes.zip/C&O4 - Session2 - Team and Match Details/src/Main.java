import java.util.Scanner;


public class Main 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter the player count");
		int pCount = Integer.parseInt(scanner.nextLine());
		
		Player[] PlayerList = new Player[pCount];
		
		for(int i=0;i<pCount;i++)
		{
			System.out.println("Enter Player " + i + " details");
			PlayerList[i] = PlayerBO.createPlayer(scanner.nextLine());	
		}
		
		System.out.println("Enter the team count");
		int tCount = Integer.parseInt(scanner.nextLine());
		
		Team[] teamList = new Team[tCount];
		
		for(int i=0;i<tCount;i++)
		{
			System.out.println("Enter team " + i + " details");
			teamList[i] = TeamBO.createTeam(scanner.nextLine(), PlayerList);
		}
		
		
		
		
		
	}
}
