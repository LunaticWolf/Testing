
public class TeamBO 
{
	public static Team createTeam(String data,Player[] PlayerList)
	{
		String[] splitTeams = data.split(",");
		
		String teamName = splitTeams[0];
		String playerName = splitTeams[1];
				
		for(Player player : PlayerList)
		{
			if
		}
		
		return null;
		
	}
}
