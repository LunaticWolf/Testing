
public class PlayerBO 
{
		
	public static Player createPlayer(String data)
	{
		String[] splitPlayers = data.split(",");
		
		String name = splitPlayers[0];
		String country = splitPlayers[1];
		String skill = splitPlayers[2];
		
		return new Player(name, country, skill);
				
	}
		
}
