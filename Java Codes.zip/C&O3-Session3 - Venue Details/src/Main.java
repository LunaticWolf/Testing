import java.util.Scanner;


public class Main 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		VenueBO venueBO = new VenueBO();
		
		System.out.println("Enter the venue name");
		String name = scanner.nextLine();
		
		System.out.println("Enter the city name");
		String city = scanner.nextLine();
		
		Venue venue = new Venue(name, city);
		venueBO.displayVenueDetails(venue);
		
		
	}
}
