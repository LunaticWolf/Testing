
public class VenueBO 
{
	public void displayVenueDetails(Venue venue)
	{
		System.out.println("Venue Details");
		System.out.println(venue.toString());
	}
}
