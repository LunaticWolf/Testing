
public class UserMainCode 
{
	public static int vowelcount(String team)
	{
		int count = 0;
		team = team.toLowerCase();
		for(int i=0;i<team.length();i++)
		if(team.charAt(i)=='a' || team.charAt(i)=='e' ||team.charAt(i)=='i' ||team.charAt(i)=='o' ||team.charAt(i)=='u')
			count+=1;
		
		return count;
	}
}
