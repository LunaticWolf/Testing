import java.util.Scanner;


public class Main 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		
			String team = scanner.nextLine();
			System.out.println(UserMainCode.vowelcount(team));
		
		scanner.close();
	}
}
