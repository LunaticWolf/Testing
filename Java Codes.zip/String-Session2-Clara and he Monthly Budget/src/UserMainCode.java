
public class UserMainCode 
{
	public static int fixMistake(String data)
	{
		
		int count = 0;
		
		for(int i=0;i<data.length();i++)
		{
			
		}
		
		return count;
	}
}
