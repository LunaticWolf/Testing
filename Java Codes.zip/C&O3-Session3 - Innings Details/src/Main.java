import java.util.Scanner;


public class Main 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		Innings[] innings = new Innings[2];
		InningsBO inningsBO = new InningsBO();
		
		for(int i =0;i<2;i++)
		{
			int j=i+1;
			
			String s = null;
			if(j==1)
				s = "First";
			else if(j==2)
				s = "Second";
			
			
			System.out.println("Enter the values for "+s+"Innings");
			
			System.out.println("Enter the BattingTeam");
			String battingTeam = scanner.nextLine();
			
			System.out.println("Enter the runs scored");
			long runs = Long.parseLong(scanner.nextLine());
			
			innings[i] = new Innings(battingTeam, runs);
			
		}
		
			inningsBO.displayAllInningsDetails(innings);
	
	}
}
