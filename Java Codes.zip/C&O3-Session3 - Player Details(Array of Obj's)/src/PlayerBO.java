
class PlayerBO extends Player
{
	
	public void displayAllPlayerDetails(Player[] player)
	{
		System.out.println("Player Details");
		
		for(int i=0;i<player.length;i++)
		{
			System.out.println(player[i].toString());
		}
	}
	
	
}
