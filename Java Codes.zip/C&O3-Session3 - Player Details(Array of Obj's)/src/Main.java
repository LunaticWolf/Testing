import java.util.Scanner;


public class Main 
{

	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		PlayerBO playerBO = new PlayerBO();
		
		System.out.println("Enter the number of players");
		int n = scanner.nextInt();
		Player[] player = new Player[n];
		scanner.nextLine();
		
		for(int i =0;i<n;i++)
		{
			System.out.println("Enter the player name");
			String name = scanner.nextLine();
		
			System.out.println("Enter the country name");
			String country = scanner.nextLine();
		
			System.out.println("Enter the skill");
			String skill = scanner.nextLine();
		
			player[i] = new Player(name, country, skill);
		}
			
			playerBO.displayAllPlayerDetails(player);

			
		scanner.close();
	}
}
