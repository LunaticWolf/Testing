/*import java.util.ArrayList;

import org.w3c.dom.ls.LSException;

import java.util.Scanner;
import java.util.TreeSet;


public class Main 
{
	public static void main(String[] args) 
	{
		String s = "Java";
		int pos = s.indexOf('a');
		Character s1='a';
		int c=0;
		
		while(pos!=-1)
		{
			c++;
			pos = s.indexOf(s1,pos+1);
		}

		
		if(s.indexOf('a')==s.lastIndexOf('a'))
			System.out.println("Same");
		else
			System.out.println("No");
		
		System.out.println("postion: " +pos);
		System.out.println("count = " + c);
		
		
		
		String s1 = "bacn v apcja pojc apm'pocj ' jc'";
		String[] d = s1.split(" +");
		
		
		
	}
}



class Main
{
	public static void main(String[] args) 
	{
	 Scanner sc = new Scanner(System.in);
	 
	 String s1 = sc.nextLine();
	 String s2 = sc.nextLine();
	 
	 System.out.println("Value - " + s1.compareTo(s2));
	 
	 
	ArrayList list = new ArrayList();
	ArrayList mlist = new ArrayList();
		//TreeSet<String> list = new TreeSet<>();
		//HashSet list = new HashSet();
		String s1=null;
		String s2=null;
		String s3=new String("Java");
		Character s4 = new Character('J');
		int i = 5;
		String f = (String) "2.5";
		double d = 5.26;
		
		
		
		
		
		list.add(f);
		list.add(5.26f);
		System.out.println("Size - "+ list.size());
		list.add(d);
		System.out.println("Size - "+ list.size());
		
		//list.add(s1);
		mlist.add(s3);
		mlist.add(i);
		mlist.add(i);
		mlist.add(new Integer(3));
		//list.add(f);
		//list.add(d);
		System.out.println("Size - "+ list.size());
		
	
		
		//System.out.println("Size - "+ list.get(2)+ "instance" + s3 instanceof String);
		System.out.println("Contains - " + list.contains(5));

		System.out.println("Size - "+ list.size());
		list.addAll(mlist);
		
		for(int j=0;j<list.size();j++)
			System.out.println(list.get(j));
		
		
		System.out.println("Size - "+ list.size());	
		System.out.println(list.contains('J'));
		System.out.println("Index - " + list.indexOf(f));
//		System.out.println("Pos - " + list.indexOf(list.contains(s3)));

		list.retainAll(mlist);

		for(int j=0;j<list.size();j++)
			System.out.println(list.get(j));
		System.out.println("Size - " + list.size());
	}
}
*/






/*class Main{
public static void main(String args[]){
int a[] = { 65, 66, 67, 68};
String s = new String(a, 1, 3);
System.out.println(s);
}
}*/







class Main
{
	A a = new 
}





