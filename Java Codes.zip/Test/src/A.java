class Singleton
{
	private Singleton instance;
	private int id;
	
	private Singleton(){}
	
	
	static public Singleton getInstance()
	{
		if(instance ==null)
		{
			
		}
	}
	
	
}