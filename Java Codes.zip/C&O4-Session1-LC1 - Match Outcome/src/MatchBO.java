
public class MatchBO 
{
	
	static String dated = "Date";
	static String team1 = "Team1";
	static String team2 = "Team2";
	static String venue = "Venue";
	static String status = "Status";
	static String winner = "Winner";
	
	public static void display()
	{
		System.out.println("Match Details");
		System.out.println(String.format("%-15s %-15s %-15s %-15s %-15s %s", dated, team1, team2, venue, status, winner));
	}
	
	public void menu()
	{
		System.out.println("Menu");
		System.out.println("1.View match details\n2.Filter match details with outcome status\n3.Filter match details with outcome winner team\n4.Exit");
		System.out.println("Enter your choice");
	}
	
	
	public void printAllMatchDetails(Match[] matchList)
	{	
		display();
		for(int i=0;i<matchList.length;i++)
		{
			System.out.println(matchList[i].toString());
		}
		
	}
	
	public void printMatchDetailsWithOutcomeStatus(Match[] matchList, String outcomeStatus)
	{
		display();
		for(int i=0;i<matchList.length;i++)
		{
			if(matchList[i].outcome.getStatus().equals(outcomeStatus))
			{
				System.out.println(matchList[i].toString());
			}
		}
		
	}
	
	
	public void printMatchDetailsWithOutcomeWinnerTeam(Match[] matchList, String outcomeWinnerTeam)
	{
		display();
		for(int i=0;i<matchList.length;i++)
		{
			if(matchList[i].outcome.getWinnerTeam().equals(outcomeWinnerTeam))
			{
				System.out.println(matchList[i].toString());
			}
		}
	}
	
}
