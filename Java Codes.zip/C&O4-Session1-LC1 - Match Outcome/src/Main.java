import java.util.Scanner;


public class Main 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		Outcome outcome = new Outcome();
		MatchBO matchBO = new MatchBO();
		
		
		System.out.println("Enter number of matches");
		int n = scanner.nextInt();
		
		Match[] match = new Match[n];
		//Outcome[] outcome = new Outcome[n];
		scanner.nextLine();
		
				
		for(int i=0;i<n;i++)
		{
			int j=i+1;
			System.out.println("Enter match " + j + " details:");
			System.out.println("Enter match date");
			String date = scanner.nextLine();
			
			System.out.println("Enter team one");
			String teamOne = scanner.nextLine();
			
			System.out.println("Enter team two");
			String teamTwo = scanner.nextLine();
			
			System.out.println("Enter venue");
			String venue = scanner.nextLine();
			
			System.out.println("Enter status");
			String status = scanner.nextLine();
			//outcome[i].setStatus(scanner.nextLine());
			
			System.out.println("Enter winner Team");
			String winnerTeam = scanner.nextLine();
			//outcome[i].setWinnerTeam(scanner.nextLine());
			
			outcome = new Outcome(status, winnerTeam);
			match[i] = new Match(date, teamOne, teamTwo, venue, outcome);
			
		}
		
		/*System.out.println("Menu");
		System.out.println("1.View match details\n2.2.Filter match details with outcome status\n3.Filter match details with outcome winner team\n4.Exit");
		System.out.println("\nEnter your choice");*/
		
//		matchBO.menu();
//		int choice = scanner.nextInt();
//		
//		scanner.nextLine();
		boolean isContinue=true;
		while(isContinue)
		{
			matchBO.menu();
			int choice = Integer.parseInt(scanner.nextLine());
			switch(choice)
			{
				case 1: matchBO.printAllMatchDetails(match);
             			break;
			
				case 2: System.out.println("Enter outcome status");
						String status = scanner.nextLine();
						matchBO.printMatchDetailsWithOutcomeStatus(match, status);
			    		break;
			
				case 3: System.out.println("Enter outcome winner team");
						String winnerTeam = scanner.nextLine();
						matchBO.printMatchDetailsWithOutcomeWinnerTeam(match, winnerTeam);
				    	break;
			
				case 4: 
					
					  isContinue =false;
					  break;
			}
		}
		
		
		scanner.close();
		
		
	}
}
