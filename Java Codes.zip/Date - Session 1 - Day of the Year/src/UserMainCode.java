import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class UserMainCode 
{

	public static void displayDay(String date) throws ParseException
	{
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date convertedDate = sdf.parse(date);
		
		String[] yearLine = date.split("-");
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy");
		Date year = sdf1.a
		
		
		
		
		//DateFormat df = new SimpleDateFormat("dd/MM/yyyy, H:mm:ss");
		 
		//System.out.println(df.format(convertedDate));
		
	}
	
}


