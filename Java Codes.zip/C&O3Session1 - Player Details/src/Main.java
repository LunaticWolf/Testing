import java.util.Scanner;


public class Main 
{

	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter the player name");
		String name = scanner.nextLine();
		
		System.out.println("Enter the country name");
		String country = scanner.nextLine();
		
		System.out.println("Enter the skill");
		String skill = scanner.nextLine();
		
		Player player = new Player(name, country, skill);
		PlayerBO playerBO = new PlayerBO();
		
		playerBO.displayAllPlayerDetails(player);

		scanner.close();
	}
}
