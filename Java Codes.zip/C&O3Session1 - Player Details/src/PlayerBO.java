
class PlayerBO extends Player
{

	public void displayAllPlayerDetails(Player player)
	{
		System.out.println("Player Details");
	
			System.out.println(player.toString());
	}
	
	
}
