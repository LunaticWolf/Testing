import java.util.Scanner;


public class Main 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter player names");
		String player1 = scanner.nextLine();
		String player2 = scanner.nextLine();
		if(player1.regionMatches(0, player2, 0, player1.substring(0).length()))
		{
			System.out.println("Both the players names starts with " + player1.substring(0));
		}
		else
			System.out.println("Both the players names does not starts with " + player1.substring(0));
	
		
		scanner.close();
	}
}
