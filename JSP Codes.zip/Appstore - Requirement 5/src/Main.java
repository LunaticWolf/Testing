
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Main 
{
	
	public static void main(String[] args) throws NumberFormatException, IOException, ParseException
	{
		List<Review> list = new ArrayList<>();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number of reviews:");
		int numberOfReviews = Integer.parseInt(br.readLine());
		
		Review[] review = new Review[numberOfReviews];
		
		for(int i=0;i<numberOfReviews;i++)
		{
			String[] details = br.readLine().split(",");
			
			String reviewerName = details[0];
			String reviewerEmail = details[1];
			String description = details[2];
			double rating = Double.parseDouble(details[3]);
			Date postedDate = new SimpleDateFormat("dd-MM-yyyy").parse(br.readLine());
			
			review[i] =new Review(reviewerName, reviewerEmail, description, rating, postedDate);
			
			list.add(review[i]);
		}
		
		
		System.out.println("enter a type to sort");
		System.out.println("1.Sort by rating");
		System.out.println("2.Sort by posted date");
		int choice = Integer.parseInt(br.readLine());
		
		switch(choice)
		{
		case 1: 
			break;
			
		case 2:
			break;
			
			default:
		}
		
		
	}
}