import java.util.Comparator;


public class PostedDateComparator<T> implements Comparator<T>
{

	@Override
	public int compare(T arg0, T arg1) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
