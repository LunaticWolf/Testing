import java.util.Date;


public class Review<T> implements Comparable<T>
{
	private String reviewerName;
	private String reviewerEmail;
	private String description;
	private double rating;
	private Date postedDate;
	
	public Review() {}
	
	public Review(String reviewerName, String reviewerEmail,
			String description, double rating, Date postedDate) {
		super();
		this.reviewerName = reviewerName;
		this.reviewerEmail = reviewerEmail;
		this.description = description;
		this.rating = rating;
		this.postedDate = postedDate;
	}

	public String getReviewerName() {
		return reviewerName;
	}

	public void setReviewerName(String reviewerName) {
		this.reviewerName = reviewerName;
	}

	public String getReviewerEmail() {
		return reviewerEmail;
	}

	public void setReviewerEmail(String reviewerEmail) {
		this.reviewerEmail = reviewerEmail;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public Date getPostedDate() {
		return postedDate;
	}

	public void setPostedDate(Date postedDate) {
		this.postedDate = postedDate;
	}

	@Override
	public String toString() {
		return String.format("%-15s %-20s %-15s  %-10s %s",reviewerName,reviewerEmail,description,rating,postedDate);
	}

	@Override
	public int compareTo(T arg0) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	
	
	
	
}
