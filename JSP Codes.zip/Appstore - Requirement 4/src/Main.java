
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Main 
{
	static List<App> applist = new ArrayList<>();
	public static void main(String[] args) throws NumberFormatException, IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter the number of apps:");
		int noOfApps = Integer.parseInt(br.readLine());
		
		App[] app = new App[noOfApps];
		for(int i=0;i<noOfApps;i++)
		{
			String[] details = br.readLine().split(",");
			
			String name = details[0];
			String category = details[1];
			int noOfDownloads = Integer.parseInt(details[2]);
			double size = Double.parseDouble(details[3]);
			
			app[i] = new App(name, category, noOfDownloads, size);
			
			applist.add(app[i]);
		}
		
		
		TreeMap<String,Integer> map = (TreeMap<String, Integer>) App.categoryWiseCount(applist);
		
		System.out.println(String.format("%-15s %s\n", "Category", "Count"));
		
		Iterator<String> it = (Iterator<String>) map.;
		while(it.hasNext())
		{
			System.out.println(String.format("%-15s %s\n",));
		}
		
		
	}
}