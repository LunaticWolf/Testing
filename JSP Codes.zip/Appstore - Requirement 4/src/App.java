
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;


public class App 
{
	private String name;
	private String category;
	private int noOfDownloads;
	private double size;
	
	
	public App(){}

	public App(String name, String category, int noOfDownloads, double size) {
		super();
		this.name = name;
		this.category = category;
		this.noOfDownloads = noOfDownloads;
		this.size = size;
	}

	
	


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getNoOfDownloads() {
		return noOfDownloads;
	}

	public void setNoOfDownloads(int noOfDownloads) {
		this.noOfDownloads = noOfDownloads;
	}

	public double getSize() {
		return size;
	}

	public void setSize(double size) {
		this.size = size;
	}
	

	
	
	public static Map<String,Integer> categoryWiseCount(List<App> appList) 
	{
		int count = 0;
		TreeMap<String,Integer> map = new TreeMap<>();
		//TreeSet<String> t = new TreeSet<>();
		
		String[] category = new String[appList.size()];
		
		int i=0;
		for(App app: appList)
		{
			category[i] = app.getCategory(); 
			i++;
		}
		
		for(i=0;i<category.length;i++)
		{
			String c = category[i];
			for(int j=0;j<category.length;j++)
			{
				if(c.equals(category[j]))
					count++;
			}
			
			map.put(c, count);
		}
		
		
		return map;
	
	}
	
	
}
