import java.util.ArrayList;
import java.util.List;

public class AppBO {
	private List<App> categoryList= new ArrayList<>();
	private List<App> sizeList = new ArrayList<>();

	public List<App> findApp(List<App> appList, String category) 
	{
		
		for(App app: appList)
		{
			if(category.equals(app.getCategory()))
				categoryList.add(app);
		}
		
		return categoryList;
	
	}
	
	public List<App> findApp(List<App> appList, Double size) 
	{	
		for(App app: appList)
		{
			if(size> app.getSize())
				sizeList.add(app);
		}
		
		return sizeList;

	}
}
