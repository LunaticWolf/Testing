import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main 
{
	private static  App[] app = null;
	private static List<App> appList = new ArrayList<>();
	
	public static void main(String args[]) throws NumberFormatException, IOException 
	{
	
		
		AppBO appBO = new AppBO();
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				
		System.out.println("Enter the number of Apps:");
		int noOfApps = Integer.parseInt(br.readLine());
		
		app=new App[noOfApps];
		for(int i=0;i<noOfApps;i++)
		{	
			String[] apps = br.readLine().split(",");
			
			String name = apps[0].toString();
			String category = apps[1].toString();
			int noOfDownloads = Integer.parseInt(apps[2]);
			double size = Double.parseDouble(apps[3]);
			
			app[i] = new App(name, category, noOfDownloads, size);
			appList.add(app[i]);
		}
			
		System.out.println("Enter a search type:\n1.By Category\n2.By Size");
		int searchType = Integer.parseInt(br.readLine());
		
		switch(searchType)
		{
		case 1: System.out.println("Enter the Category:");
				String category = br.readLine().toString();
				List<App> categoryList = appBO.findApp(appList , category);
				if(categoryList.size()>0)
				{
					System.out.println(String.format("%-10s %-15s %-5s %s", "Name","Category","Size","No. Of Downloads"));
					for(App categoryDetails: categoryList)
					System.out.println(categoryDetails.toString());
				}
				else
					System.out.println("No such app is present");
				
			break;
			
		case 2: System.out.println("Enter the size:");
				double size = Double.parseDouble(br.readLine());
				List<App> sizeList = appBO.findApp(appList , size);
				if(sizeList.size()>0)
				{
					System.out.println(String.format("%-10s %-15s %-5s %s", "Name","Category","Size","No. Of Downloads"));
					for(App sizeDetails: sizeList)
					System.out.println(sizeDetails.toString());
				}
				else
					System.out.println("No such app is present");
			break;
		default: System.out.println("Invalid Choice");
		}
		
		
		br.close();
		
	}
}
