
public class App
{
	private String name;
	private String category;
	private int noOfDownloads;
	private double size;
	
	
	public App() {}



	public App(String name, String category, int noOfDownloads, double size) {
		super();
		this.name = name;
		this.category = category;
		this.noOfDownloads = noOfDownloads;
		this.size = size;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public int getNoOfDownloads() {
		return noOfDownloads;
	}


	public void setNoOfDownloads(int noOfDownloads) {
		this.noOfDownloads = noOfDownloads;
	}


	public double getSize() {
		return size;
	}


	public void setSize(double size) {
		this.size = size;
	}


	@Override
	public String toString() {
		return String.format("%-10s %-15s %-5.1f %s", name,category,size,noOfDownloads);
	}
	
	
	
	
	
}
