
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main 
{
	static boolean validateEmail(String email)
	{
		boolean valid = false;
		boolean validLP = false;
		boolean validDP = false;
		
		boolean check1 = false;
		boolean check2 = false;
		boolean check3 = false;
		boolean check4 = false;

		String[] withAt = email.split("@");				
		if(withAt.length==2)
		{
			String localPart = withAt[0];
			String dot = ".";
			String underScore = "_";
			
			if((Character.isAlphabetic(localPart.charAt(0))))
			{
				check1 = true;
				
					for(int i=0;i<localPart.length();i++)
					{
							char checkLP = localPart.charAt(i);
					
							if(( Character.isAlphabetic(checkLP)|| Character.isDigit(checkLP) || String.valueOf(checkLP).equals(dot) || String.valueOf(checkLP).equals(underScore) ))
								check2 = true;
							else
							{
								check2=false;
								break;				
							}
					}
			}
			
		}
			
			
		
		
		
		//System.out.println("Check1 - " + check1);
		//System.out.println("Check2 - " + check2);
			
			if(check1&&check2)
			validLP = true;
			
			
//----------------------------------------------------------------------------Part 2
			
			
		

			String[] withDot = withAt[1].split("\\.");
			if(withDot.length==2)
			{
				for(int i=0;i<withDot[0].length();i++)
				{
					char checkDomain = withDot[0].charAt(i);
					if(Character.isAlphabetic(checkDomain))
						check3 = true;
					else
					{
						check3 = false;
						break;
					}
			
				}
			
				if(withDot[1].length()>1 && withDot[1].length()<7)
				{
					for(int i=0;i<withDot[1].length();i++)
					{	
						char checkTLD = withDot[1].charAt(i);
						if(Character.isAlphabetic(checkTLD))
							check4 = true;
						else
						{
							check4 = false;
							break;
						}
					}	
				}
				
				
				
				//System.out.println("Check3 - " + check3);
				//System.out.println("Check4 - " + check4);
				
				if(check3&&check4)
					validDP = true;
			}
				
			
			
			
			if(validLP && validDP)
				valid = true;
		
				
				return valid;
	}
	
	
	
	
	
	
	
	
	
	public static void main(String[] args) throws IOException
    {
    	BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    	
    	System.out.println("Enter the email to be validated:");
    	String email = reader.readLine();
    	
    	if(Main.validateEmail(email))
    		System.out.println("Email is valid");
    	else
    		System.out.println("Email is invalid");
    	
    	reader.close();
    	

    }
}
