package com.user.beans.customtags;
import com.user.beans.*;

import java.io.IOException;
import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class CustomTableTag extends SimpleTagSupport
{
	
	
	private List<PersonalDetails> personalDetails;
	private String[] headers; 
	
	public void setHeaders(String[] headers) {
		this.headers = headers;
	}

	public void setPersonalDetails(List<PersonalDetails> personalDetails) {
		this.personalDetails = personalDetails;
	}





	@Override
	public void doTag() throws JspException, IOException 
	{
		
		JspWriter out = getJspContext().getOut();
		
		out.println("<table><tr>");
		for(int i=0;i<headers.length;i++)
		{
			out.println("<th>" + headers[i] + "</th>");
		} 
		
		
		out.print("</tr>");
		for(PersonalDetails personalDetailsList: personalDetails)
		{
			out.print("<tr>");
			out.print("<td>" + personalDetailsList.getName() + "</td>");
			out.print("<td>" + personalDetailsList.getEmail() + "</td>");
			out.print("<td>" + personalDetailsList.getPhoneNo() + "</td>");
			out.print("</tr>");
		}
		
		
		
		
		
		
	}
}
