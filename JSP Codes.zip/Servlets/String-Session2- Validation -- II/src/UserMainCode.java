
public class UserMainCode 
{
	public static boolean validateTeam(String data)
	{
		String[] details = data.split("-");
		String[] teamName = details[0].split(" ");
		
		boolean valid = false;
		
		if(!(details.length==1))
		{
			StringBuffer sb = new StringBuffer();
			for(int i=0;i<teamName.length;i++)
			{
				sb.append(teamName[i].charAt(0));
			}
			
			if(sb.toString().equals(details[1]))
				valid=true;
		}
		
		return valid;
		
	}
}
