import java.util.Scanner;


public class Main
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		
		if(UserMainCode.validateTeam(scanner.nextLine()))
			System.out.println("Valid");
		else
			System.out.println("Invalid");
		
		scanner.close();
	}
}
