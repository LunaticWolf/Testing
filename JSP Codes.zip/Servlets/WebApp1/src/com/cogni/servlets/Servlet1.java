package com.cogni.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




public class Servlet1 extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	/*static ServletConfig config;*/
	/*String message;*/
	static ServletContext context;
	String countValue="";
	
    
    public Servlet1() 
    {
        super();
    }

    
   /* @Override
    public void init(ServletConfig config) throws ServletException 
    {   
    	super.init();
    	this.config = config;
    	message = config.getInitParameter("Message");
    	
    }*/
    
    
    @Override
    public void init(ServletConfig config) throws ServletException 
    {
    	context = config.getServletContext();
    	countValue = context.getInitParameter("count");
    }
    
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
//		response.setContentType("html/text");
	
		
		String msg = context.getInitParameter("Message");
		
		if(context.getAttribute("myCount")!=null)
		{
			countValue = (String) context.getInitParameter("myCount");
		}
		
		int n = Integer.parseInt(countValue);
		n++;
		
		context.setAttribute("myCount", Integer.toString(n));
		
			PrintWriter out = response.getWriter();
			String s1 = "<html> <body> <h1>" + msg + "</h1> <p> count - " + context.getAttribute("myCount") + "</p></body> </html>";
			out.write(s1);
		
			
		
//			String user = request.getParameter("userName");
//			String pwd  = request.getParameter("password");
//			
//			if(user!=null && pwd.length() == 6)
//			response.sendRedirect("Success.html");
//			else
//				out.write("Invalid Details");*/
//			
			
			
			
	}


	

}
