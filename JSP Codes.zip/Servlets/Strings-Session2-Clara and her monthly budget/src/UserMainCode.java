
public class UserMainCode 
{
	public static int getValue(String data)
	{
		int count =0;
		int testcount = 0;
		boolean valid = false;
		
		if(data.length()<2)
		{
			valid = false;
		}
		else if(data.length()<51)
		{
			for(int i=0;i< data.length();i++)
			{
				if(Character.isDigit(data.charAt(i)))
					testcount++;
			}
			
			if(testcount == data.length())
				valid = true;
		
		}
	
		
			
		if(valid)
		{
			int[] length3 = new int[data.length()-2];
			
			for(int i=0;i<data.length();i++)
			{
				if(i==data.length()-2)
					break;
				else
					{
						length3[i] = Integer.parseInt(data.substring(i, i+3));
						
					}
			}
			
			
			for(int i=0;i<length3.length;i++)
			{
				if(length3[i]%4==0)
				{
					
					count++;
				}
				
			}
		
		}
		
		return count;
	}
}
