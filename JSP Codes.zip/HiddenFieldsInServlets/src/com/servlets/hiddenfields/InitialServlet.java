package com.servlets.hiddenfields;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class InitialServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out = response.getWriter();
		
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String userName = request.getParameter("userName");
		
		
				String s =  "<html><body>";
				 s+="<form name='myOtherForm' action='FinalServlet' method='post'>";
				 s+=  "<tr> <td> Qualification: </td> <td> <input type='text' name='qualification' /> </td> </tr><br>";
				 s+=  "<tr> <td> College: </td> <td> <input type='text' name='college' /> </td> </tr><br>";
				 s+=  "<tr> <td> <input type='text' name='firstName'  value=" + firstName + " /> </td> </tr><br>";
				 s+=  "<tr> <td> <input type='hidden' name='lastName'   value=" + lastName + " /> </td> </tr><br>";
				 s+=  "<tr> <td> <input type='hidden' name='userName'   value=" + userName + " /> </td> </tr><br>";
				 s+=  "<tr> <td><input type='Submit' value='Register' /> </td></tr>";
				 s+=  "</form></body></html>";
				
				 
				 //or we can use url rewriting to send the data to other servlets instead of using hidden types
				// response.sendRedirect("FinalServlet?firstName=" + firstName + "&lastName=" + lastName + "&userName"+userName + );
				 //now the values are avaliable in final servlet doGET METHOD(default,since values are visible in url) and can be used(Similar to user input values)
				 
				 out.println(s);		
				
						
		
		
	}

}
