package com.servlets.hiddenfields;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class FinalServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		PrintWriter out = response.getWriter();
		
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String userName = request.getParameter("userName");
		String qualification = request.getParameter("qualification");
		String college = request.getParameter("college");
		
		
		String s = "<html><body>";
			   s+= "<table>";
			   s+="<tr><td>FirstName: </td> <td> " + firstName + "</td></tr>"; 
			   s+="<tr><td>LastName: </td> <td> " + lastName + "</td></tr>";
			   s+="<tr><td>UserName: </td> <td> " + userName + "</td></tr>";
			   s+="<tr><td>Qualification: </td> <td> " + qualification + "</td></tr>";
			   s+="<tr><td>College: </td> <td> " + college + "</td></tr>";
			   s+="</table> <br>";
			   
			   //URL REWRITE
			   s+="<a href = 'UrlRewriteServlet?userName=" + userName;
			   s+="&firstName=" +firstName;
			   s+="&lastName=" + lastName;
			   s+="&qualification=" + qualification; 
			   s+="&college=" + college;
			   s+="'> Eg. URL Re-Writing in Servlets </a>"; 
			   
			   
			   s+="</body></html>";
			   
			   
			   out.println(s);
					
					   
		
	
	}


}
