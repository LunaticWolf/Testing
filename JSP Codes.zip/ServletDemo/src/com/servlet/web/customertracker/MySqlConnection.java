package com.servlet.web.customertracker;

import java.sql.*;

public class MySqlConnection 
{
	static Connection myConn = null;
	//static String Driver = "com.mysql.jdbc.Driver";
	static String url = "jdbc:mysql://localhost:3306/web_customer_tracker";
	static String userName = "root";
	static String password = "root";
	
	
	public MySqlConnection(){}
	
	
	public static Connection getConnection()
	//public static void main(String[] args)
	{
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
	
			//Driver driver = new com.mysql.jdbc.Driver();	
			System.out.println("Driver Class Sucessfully  Loaded...");
			System.out.println("Establishing Connection....");
			//Thread.sleep(1000);
			
			myConn =(Connection) DriverManager.getConnection(url,userName,password);
			
			System.out.println("\n\nConnection Established....");
			
		}
	
		catch(Exception e)
		{
			
			System.out.println("Connection failed....");
			e.printStackTrace();
			
		}
		return myConn;
	
	}
	
	

}
