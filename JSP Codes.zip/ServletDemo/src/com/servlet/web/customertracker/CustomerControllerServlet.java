package com.servlet.web.customertracker;

import java.io.IOException;
import java.util.List;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class CustomerControllerServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	private CustomerDbUtil customerDbUtil;
	
	
	@Override
	/*public void init() throws ServletException 
	{
		super.init();
		
		try {
			customerDbUtil = (CustomerDbUtil) MySqlConnection.getConnection();
		}
		catch (Exception exc) {
			throw new ServletException(exc);
		}
	}*/
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{

		try 
		{
			
			String theCommand = request.getParameter("command");
			
			
			if (theCommand == null) 
			{
				theCommand = "LIST";
			}
			
			switch (theCommand) 
			{
				case "LIST": listCustomers(request, response);
				break;
				
				case "ADD": addCustomer(request, response);
				break;
				
				default: listCustomers(request, response);
			}
				
		}
		catch (Exception exc) 
		{
			throw new ServletException(exc);
		}
		
	}



	private void addCustomer(HttpServletRequest request, HttpServletResponse response) throws Exception 
	{

		// read customer info from form data
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String email = request.getParameter("email");		
		
		// create a new customer object
		Customer theCustomer = new Customer(firstName, lastName, email);
		
		// adding customer to the database
		customerDbUtil.addCustomer(theCustomer);
				
		// send back to main page (to the customer list page)
		listCustomers(request, response);
	}

	private void listCustomers(HttpServletRequest request, HttpServletResponse response) 
		throws Exception 
		{

		// get customers from db util
		List<Customer> customers = customerDbUtil.getCustomers();
		
		if(customers==null)
		{
			System.out.println("Null Value");
		}
		else
		{
			// add customers to the request
			request.setAttribute("CUSTOMER_LIST", customers);
			
		}
		// send to JSP page (view)
		RequestDispatcher dispatcher = request.getRequestDispatcher("/list-customers.jsp");
		dispatcher.forward(request, response);
	}

}

