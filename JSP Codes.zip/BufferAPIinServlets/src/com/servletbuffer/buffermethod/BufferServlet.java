package com.servletbuffer.buffermethod;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class BufferServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
		//use get/setBufferSize(int n), isCommited(), flushBuffer()
  
    public BufferServlet() { super();}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
			response.setContentType("text/html");
			response.setBufferSize(1024*4);
			PrintWriter out = response.getWriter();
			
			String s1 = "<h1>Kamehameha...</h1>";
			String s2 = "<h2><i>KioKen...</i></h2>";
			String s3 = "<h2><b>Final Flash</b></h2>";
			String s4 = "<h2><i><b><Kabooooommmmmmmmmmm</b></i></h1>";
			
			String s5 = "<h1>Ka..me..ha..me..ha...</h1>";
			String s6 = "<h1>Kaa....me....ha...me...haa.....</h1>";
			String s7 = "<h1>Final Kamehameha... </h1>";
			
			out.println(s1);
			out.println(s2);
			out.println(s3);
			
			
			
			if(response.isCommitted())
			{
				out.println(s4);
			}
			else
			{
				response.reset();
				response.setContentType("text/html");
				
				out.println(s5);
				response.resetBuffer();
				
				out.println(s6);
				response.flushBuffer();
				
			}
			
			
			out.println(s7);
			out.println("<h3> Times - <h1>" + response.getBufferSize() + "</h1> </h3>");
			
		
	}

	

		

}
