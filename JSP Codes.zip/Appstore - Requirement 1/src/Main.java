import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main 
{
	public static void main(String args[])
	{
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		Developer developer1 = null;
		Developer developer2 = null;
		
		try
		{
			System.out.println("Enter developer 1 details:");
			String[] d1 = reader.readLine().split(",");
			developer1 = new Developer(d1[0], d1[1]);
			
			
			System.out.println("Enter developer 2 details:");
			String[] d2 = reader.readLine().split(",");
			developer2 = new Developer(d2[0], d2[1]);
			
			
			
			
			System.out.println("\nDeveloper 1\n" + developer1.toString());
			System.out.println("\nDeveloper 2\n" + developer2.toString());
			
			
			if(developer1.equals(developer2))
					System.out.println("\nDeveloper 1 is same as Developer 2");
			else
				System.out.println("\nDeveloper 1 and Developer 2 are different");
		
			
			
			reader.close();
	
		
		} 
	
		catch (IOException e) 
		{
			e.printStackTrace();
		}
				
		
		
		
	} 
}
