package com.servlets.cookie;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class CookieResultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public CookieResultServlet() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out = response.getWriter();
		
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		
		String s = "<html><body>";
			   s+="<p>Username: " + userName;
			   s+="</p><br>";
			   s+="<p>Password: " + password;
			   s+="</p></body></html>";
		
			   out.print(s);
		
		
	}

}
