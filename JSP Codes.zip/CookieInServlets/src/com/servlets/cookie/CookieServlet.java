package com.servlets.cookie;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class CookieServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		Cookie[] allCookies = request.getCookies();
		
		String userName="";
		String password="";
		
		for(Cookie cookie: allCookies)
		{
			if("UserName".equals(cookie.getName()))
			{
				userName = cookie.getValue();
			}
			
			if("Password".equals(cookie.getName()))
			{
				password = "******";
			}
		}
		
		
		response.sendRedirect("CookieResultServlet?userName=" + userName + "&password=" + password);
		
	}


}
