import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Main 
{
	public static void main(String args[]) throws NumberFormatException, IOException, ParseException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		
		System.out.println("Enter the number of reviews:");
		int noOfReviews = Integer.parseInt(br.readLine());
		
		List<Review> reviewList = new ArrayList<>();
		List<App> appList = App.prefill();
		
		
		for(int i=0;i<noOfReviews;i++)
		{
			String[] details = br.readLine().split(",");
			
			String reviewerName = details[0];
			String reviewerEmail = details[1];
			String description = details[2];
			double rating = Double.parseDouble(details[3]);
			
			Date postedDate = sdf.parse(details[4]);
			String appName = details[5];
			
			Review  review = new Review(reviewerName, reviewerEmail, description, rating, postedDate, null);
			for (App app :appList) {
				if (app.getName().equals(appName))
				{
					app.getReviewList().add(review);
					review.setApp(app);
				}
			}
		}
		
		
		App  trendingApp = App.getTrendingApp(appList);
		
		System.out.println("The trending app is " + trendingApp.getName() );
		
		
		
	}
}
