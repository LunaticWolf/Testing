import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class App 
{
	private String name;
	private String category;
	private int noOfDownloads;
	private double size;
	List<Review> reviewList;

	
	public App() {}	
	
	public App(String name, String category, int noOfDownloads, double size,
			List<Review> reviewList) {
		super();
		this.name = name;
		this.category = category;
		this.noOfDownloads = noOfDownloads;
		this.size = size;
		this.reviewList = reviewList;
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getNoOfDownloads() {
		return noOfDownloads;
	}

	public void setNoOfDownloads(int noOfDownloads) {
		this.noOfDownloads = noOfDownloads;
	}

	public double getSize() {
		return size;
	}

	public void setSize(double size) {
		this.size = size;
	}

	public List<Review> getReviewList() {
		return reviewList;
	}

	public void setReviewList(List<Review> reviewList) {
		this.reviewList = reviewList;
	}

	
	
	
	public static List<App> prefill() 
	{
		List<App> appList = new ArrayList<>();
		appList.add(new App("Whatsapp","Communication",Integer.parseInt("1296"),Double.parseDouble("16.5"),new ArrayList<Review>()));
		appList.add(new App("MX player","Video player",Integer.parseInt("512"),Double.parseDouble("20.0"),new ArrayList<Review>()));
		appList.add(new App("Facebook","Social",Integer.parseInt("750"),Double.parseDouble("54.0"),new ArrayList<Review>()));
		appList.add(new App("UC browser","Browser",Integer.parseInt("456"),Double.parseDouble("34.0"),new ArrayList<Review>()));
		appList.add(new App("IMO","Communication",Integer.parseInt("526"),Double.parseDouble("10.5"),new ArrayList<Review>()));
		appList.add(new App("Hotstar","Entertainment",Integer.parseInt("400"),Double.parseDouble("65.0"),new ArrayList<Review>()));
		appList.add(new App("Opera mini","Browser",Integer.parseInt("365"),Double.parseDouble("26.3"),new ArrayList<Review>()));
		appList.add(new App("Airtel TV","Entertainment",Integer.parseInt("569"),Double.parseDouble("56.3"),new ArrayList<Review>()));
		appList.add(new App("VLC player","Video player",Integer.parseInt("623"),Double.parseDouble("37.5"),new ArrayList<Review>()));
		appList.add(new App("Twitter","Social",Integer.parseInt("783"),Double.parseDouble("12.6"),new ArrayList<Review>()));
		appList.add(new App("Instagram","Social",Integer.parseInt("800"),Double.parseDouble("62.5"),new ArrayList<Review>()));
		appList.add(new App("Jio tv","Entertainment",Integer.parseInt("296"),Double.parseDouble("45.5"),new ArrayList<Review>()));
		appList.add(new App("Hike","Communication",Integer.parseInt("540"),Double.parseDouble("30.0"),new ArrayList<Review>()));
		return appList;
	}
		
	
	
	public static App getTrendingApp(List<App> appList) 
	{
		double max = 0;
		Map<App, Double> appMap = new  HashMap<>();
		App  app1 = null;
		for(App app:appList)
		{
			double sum = 0;
			int count=0;
			for(Review review :app.getReviewList())
			{
				double topRating = review.getRating();
				sum+=topRating;
				count++;
			}
			double avg=sum/count;
			appMap.put(app, avg);
			if (avg>max)
			{
				max=avg;
			}
		}
		List<App> appList1 = new  ArrayList<>();
				
		for(Entry<App, Double> entry :  appMap.entrySet()){
			if (entry.getValue()==max)
			{
				appList1.add(entry.getKey());
			}
		}
		
		if (appList1.size()>1)
		{
			for(App app  :appList1)
			{
				int sum=app.getNoOfDownloads();
				
     			if (sum>max1)
			    {
				max1=sum;
				 app1 =app;
			}
			}
			
		}
			else
			{
				app1 =appList1.get(0);
			}
			
			
			return app1;
		}

}
