import java.util.Date;

public class Review 
{
	private String reviewerName;
	private String reviewerEmail;
	private String description;
	private double rating;
	private Date postedDate;
	App app;
	
	
	
	public Review() {}



	public Review(String reviewerName, String reviewerEmail,
			String description, double rating, Date postedDate, App app) {
		super();
		this.reviewerName = reviewerName;
		this.reviewerEmail = reviewerEmail;
		this.description = description;
		this.rating = rating;
		this.postedDate = postedDate;
		this.app = app;
	}



	public String getReviewerName() {
		return reviewerName;
	}



	public void setReviewerName(String reviewerName) {
		this.reviewerName = reviewerName;
	}



	public String getReviewerEmail() {
		return reviewerEmail;
	}



	public void setReviewerEmail(String reviewerEmail) {
		this.reviewerEmail = reviewerEmail;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	public double getRating() {
		return rating;
	}



	public void setRating(double rating) {
		this.rating = rating;
	}



	public Date getPostedDate() {
		return postedDate;
	}



	public void setPostedDate(Date postedDate) {
		this.postedDate = postedDate;
	}



	public App getApp() {
		return app;
	}



	public void setApp(App app) {
		this.app = app;
	}
	
	
	
	

	
}
