package com.servlet.comms;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class HeaderServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
  
    public HeaderServlet() { super();  }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out = response.getWriter();
		
		String head = "<b><hr><div style='color:'blue';''>I'm Header</div></b>";
		String user = "<b><hr><div style='color:'red';''>" + request.getAttribute("username") + "</div></b><hr>";
		out.println(head);
		out.print(user);
		
	}



}
