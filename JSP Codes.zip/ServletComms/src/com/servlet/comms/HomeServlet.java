package com.servlet.comms;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class HomeServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
 
    public HomeServlet() {  super(); }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
		PrintWriter out = response.getWriter();
		String s1 = "<html><body>";
		String s2 = "</body></html>";
		RequestDispatcher rd = null;
		
		out.println(s1);
		
			String userName = request.getParameter("userName");
			//out.println(welcome + userName + "</h1>");
			request.setAttribute("username", userName);
			
			rd = request.getRequestDispatcher("HeaderServlet");
			rd.include(request, response);	
			
			String welcome = "<h1 style='color:'grey';'>";
			out.println(welcome);
			out.println("Home");
			out.print("</h1>");
		
		
		rd = request.getRequestDispatcher("FooterServlet");
		rd.include(request, response);
		
		out.println(s2);
				
		
	}
}