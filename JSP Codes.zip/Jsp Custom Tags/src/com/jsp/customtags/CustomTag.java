package com.jsp.customtags;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.jsp.JspContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;


public class CustomTag extends SimpleTagSupport 
{
	//Defining attribute
	/*private String format;
	public void setFormat(String format) 
	{
		this.format = format;
	}
	*/
	
	@Override
	public void doTag() throws JspException, IOException 
	{
		Date d = new Date();
		/*String date = new SimpleDateFormat(format).format(d);*/
		String date = new SimpleDateFormat("dd/MM/yyyy").format(d);
		
		JspContext context = getJspContext();
		JspWriter out = context.getOut();
		
		out.println("Date-" + date);
		
	}
}
