package com.jsp.customtags;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.jsp.JspContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class StringManipulation extends SimpleTagSupport 
{
	@Override
	public void doTag() throws JspException, IOException 
	{
		JspContext context = getJspContext();
		
		StringWriter sw = new StringWriter();
		getJspBody().invoke(sw);
		
		String str = sw.toString().toUpperCase();
		
		
		JspWriter out = context.getOut();
		out.print(str);
	}
}
