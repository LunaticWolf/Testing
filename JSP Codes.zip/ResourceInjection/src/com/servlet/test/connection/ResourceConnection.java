package com.servlet.test.connection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;




@WebServlet("/TestServlet")
public class ResourceConnection extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
	/*@Resource(name="same name as mentioned in context.xml ")*/
	@Resource(name="jdbc/mydb")
	private DataSource dataSource;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Connection myConn = null;	
		
		try 
		{
			myConn = dataSource.getConnection();
			if(myConn!=null)
				System.out.println("Connection Established - " + myConn);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println("Connection Failed");
		}
		
		
		
	}

	

}
