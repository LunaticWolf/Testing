package com.servlet.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.xml.ws.Response;


public class SimpleFilter implements Filter {
	
	static PrintWriter out = null;
	
	
	@Override
	public void init(FilterConfig arg0) throws ServletException 
	{
	}
	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException 
	{
		out = response.getWriter();
		
		String s = "<h1> Filter 1</h1>";
		out.print(s);
		
		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {
		
	}



	
	

}
