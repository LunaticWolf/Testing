package com.servlet.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Servlet Filter implementation class OtherFilter
 */
public class OtherFilter implements Filter {

   
  
	public void init(FilterConfig fConfig) throws ServletException 
	{}
	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException 
	{
		PrintWriter out = response.getWriter();
		String s = "<h2><i>  Filter 2 </i> </h2>";
		out.print(s);
		chain.doFilter(request, response);
	}

	public void destroy() 
	{}

}
